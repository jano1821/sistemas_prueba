/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author Alex
 */
public class Constantes {
    public static final int INSERTAR = 1;
    public static final int LISTAR = 2;
    public static final int BUSCAR = 3;
    public static final int ELIMINAR = 4;
    public static final int ACTUALIZAR = 5;
}
