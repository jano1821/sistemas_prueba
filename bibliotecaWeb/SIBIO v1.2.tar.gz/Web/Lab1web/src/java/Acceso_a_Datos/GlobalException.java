/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Acceso_a_Datos;

/**
 *
 * @author Alex
 */
public class GlobalException extends java.lang.Exception {

    /** Creates a new instance of GlobalException */
    public GlobalException() {
    }

    public GlobalException(String msg)
    {
        super(msg);
    }

}
