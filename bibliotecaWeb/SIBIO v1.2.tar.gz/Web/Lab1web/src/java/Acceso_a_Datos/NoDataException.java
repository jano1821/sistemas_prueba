package Acceso_a_Datos;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author Alex
 */
public class NoDataException extends java.lang.Exception {

    /** Creates a new instance of NoDataException */
    public NoDataException() {
    }

    public NoDataException(String msg) {
        super(msg);
    }
}

