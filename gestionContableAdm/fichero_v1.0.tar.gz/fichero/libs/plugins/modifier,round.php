<?php

function smarty_modifier_round($numero)
{
    return round($numero,2);
}


?>

