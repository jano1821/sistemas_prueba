<?php
namespace Vokuro\Auth;

class Exception extends \Exception
{
}
