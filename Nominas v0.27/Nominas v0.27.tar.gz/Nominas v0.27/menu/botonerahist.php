<div id="tablist">
<?php
echo("<table><tr>");
printf ("<td><button type='submit' name='actualizar'>  <img src='./imagenes/actualizar.png'> </button></td>");
echo("</table>");
?>
</div>