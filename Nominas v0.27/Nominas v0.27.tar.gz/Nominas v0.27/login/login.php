<html>
<head>
<title> Acceso al Sistema </title>
<link rel=StyleSheet href="estilos.css" TYPE="text/css">
</head>
<body>
<p>&nbsp;</p>
<center>

<form method="post" action="checklogin.php" id="login">
    <h1>Acceso</h1>
    <fieldset id="inputs">
        <input name="username" id="username" type="text" maxlength="15" placeholder="Nombre de Usuario" autofocus required>
        <input name="password" id="password" type="password" maxlength="30" placeholder="Contrase&ntilde;a" required>
    </fieldset>
    <fieldset id="actions">
        <input type="submit" id="submit" name="logarse" value="Entrar">
    </fieldset>
</form>


</center>
</body>
</html>
